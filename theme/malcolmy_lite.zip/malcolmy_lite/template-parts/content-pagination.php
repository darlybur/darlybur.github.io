<?php
/**
 * Template part for posts pagination.
 *
 * @package Malcolmy_Lite
 */
the_posts_pagination( array(
		'prev_text' => '<span>Prev</span>',
		'next_text' => '<span>Next</span>'
	)
);
